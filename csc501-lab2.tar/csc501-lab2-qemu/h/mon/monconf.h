#ifndef _MONCONF_H_
#define _MONCONF_H_

/* misc. */
typedef short   STATWORD[1];
#define TRUE		1
#define FALSE		0
#define OK		1
#define SYSERR		-1
#define NULL		0

#endif
